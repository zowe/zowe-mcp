/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type { IRpcClient } from "./doc/client";
import type { CommandRequest, CommandResponse, console, core, ds, jobs, system, tool, tso, uss } from "./doc/rpc";
import type { ProgressCallback } from "./doc/types";
export declare abstract class RpcClientApi implements IRpcClient {
    abstract request<ReqT extends CommandRequest, RespT extends CommandResponse>(request: ReqT, progressCallback?: (percent: number) => void): Promise<RespT>;
    console: {
        issueCmd: (request: Omit<console.IssueConsoleCmdRequest, "command">) => Promise<console.IssueConsoleCmdResponse>;
    };
    core: {
        getInfo: (request: Omit<core.GetInfoRequest, "command">) => Promise<core.GetInfoResponse>;
    };
    ds: {
        createDataset: (request: Omit<ds.CreateDatasetRequest, "command">) => Promise<CommandResponse>;
        createMember: (request: Omit<ds.CreateMemberRequest, "command">) => Promise<CommandResponse>;
        deleteDataset: (request: Omit<ds.DeleteDatasetRequest, "command">) => Promise<CommandResponse>;
        listDatasets: (request: Omit<ds.ListDatasetsRequest, "command">) => Promise<ds.ListDatasetsResponse>;
        listDsMembers: (request: Omit<ds.ListDsMembersRequest, "command">) => Promise<ds.ListDsMembersResponse>;
        readDataset: (request: Omit<ds.ReadDatasetRequest, "command">) => Promise<ds.ReadDatasetResponse>;
        restoreDataset: (request: Omit<ds.RestoreDatasetRequest, "command">) => Promise<CommandResponse>;
        writeDataset: (request: Omit<ds.WriteDatasetRequest, "command">) => Promise<ds.WriteDatasetResponse>;
        renameDataset: (request: Omit<ds.RenameDatasetRequest, "command">) => Promise<CommandResponse>;
        renameMember: (request: Omit<ds.RenameMemberRequest, "command">) => Promise<CommandResponse>;
        copyDatasetOrMember: (request: Omit<ds.CopyDatasetRequest, "command">) => Promise<CommandResponse>;
    };
    jobs: {
        cancelJob: (request: Omit<jobs.CancelJobRequest, "command">) => Promise<CommandResponse>;
        deleteJob: (request: Omit<jobs.DeleteJobRequest, "command">) => Promise<CommandResponse>;
        getJcl: (request: Omit<jobs.GetJclRequest, "command">) => Promise<jobs.GetJclResponse>;
        getStatus: (request: Omit<jobs.GetJobStatusRequest, "command">) => Promise<jobs.GetJobStatusResponse>;
        holdJob: (request: Omit<jobs.HoldJobRequest, "command">) => Promise<CommandResponse>;
        listJobs: (request: Omit<jobs.ListJobsRequest, "command">) => Promise<jobs.ListJobsResponse>;
        listSpools: (request: Omit<jobs.ListSpoolsRequest, "command">) => Promise<jobs.ListSpoolsResponse>;
        readSpool: (request: Omit<jobs.ReadSpoolRequest, "command">) => Promise<jobs.ReadSpoolResponse>;
        releaseJob: (request: Omit<jobs.ReleaseJobRequest, "command">) => Promise<CommandResponse>;
        submitJcl: (request: Omit<jobs.SubmitJclRequest, "command">) => Promise<jobs.SubmitJclResponse>;
        submitJob: (request: Omit<jobs.SubmitJobRequest, "command">) => Promise<jobs.SubmitJclResponse>;
        submitUss: (request: Omit<jobs.SubmitUssRequest, "command">) => Promise<jobs.SubmitJclResponse>;
    };
    system: {
        viewSyslog: (request: Omit<system.ViewSyslogRequest, "command">) => Promise<system.ViewSyslogResponse>;
        listProclib: (request: Omit<system.ListProclibRequest, "command">) => Promise<system.ListProclibResponse>;
        listApf: (request: Omit<system.ListApfRequest, "command">) => Promise<system.ListApfResponse>;
    };
    tool: {
        search: (request: Omit<tool.ToolSearchRequest, "command">) => Promise<tool.ToolSearchResponse>;
    };
    tso: {
        issueCmd: (request: Omit<tso.IssueTsoCmdRequest, "command">) => Promise<tso.IssueTsoCmdResponse>;
    };
    uss: {
        copyUss: (request: Omit<uss.CopyUssRequest, "command">) => Promise<CommandResponse>;
        chmodFile: (request: Omit<uss.ChmodFileRequest, "command">) => Promise<CommandResponse>;
        chownFile: (request: Omit<uss.ChownFileRequest, "command">) => Promise<CommandResponse>;
        chtagFile: (request: Omit<uss.ChtagFileRequest, "command">) => Promise<CommandResponse>;
        createFile: (request: Omit<uss.CreateFileRequest, "command">) => Promise<CommandResponse>;
        deleteFile: (request: Omit<uss.DeleteFileRequest, "command">) => Promise<CommandResponse>;
        listFiles: (request: Omit<uss.ListFilesRequest, "command">) => Promise<uss.ListFilesResponse>;
        readFile: (request: Omit<uss.ReadFileRequest, "command">, progressCallback?: ProgressCallback) => Promise<uss.ReadFileResponse>;
        writeFile: (request: Omit<uss.WriteFileRequest, "command">, progressCallback?: ProgressCallback) => Promise<uss.WriteFileResponse>;
        issueCmd: (request: Omit<uss.IssueUssCmdRequest, "command">) => Promise<uss.IssueUssCmdResponse>;
        moveFile: (request: Omit<uss.MoveFileRequest, "command">) => Promise<CommandResponse>;
    };
    private rpc;
    private rpcWithProgress;
}
