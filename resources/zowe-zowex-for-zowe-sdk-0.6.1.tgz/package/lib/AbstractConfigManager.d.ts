/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { type IProfileLoaded, type IProfileTypeConfiguration, type ProfileInfo } from "@zowe/imperative";
import type { ISshSession } from "@zowe/zos-uss-for-zowe-sdk";
import { type IDisposable, type inputBoxOpts, MESSAGE_TYPE, type PrivateKeyWarningOptions, type ProgressCallback, type PromptForProfileOptions, type qpItem, type qpOpts } from "./doc";
export declare abstract class AbstractConfigManager {
    private mProfilesCache;
    constructor(mProfilesCache: ProfileInfo);
    protected abstract showMessage(message: string, type: MESSAGE_TYPE): void;
    protected abstract showInputBox(opts: inputBoxOpts): Promise<string | undefined>;
    protected abstract withProgress<T>(message: string, task: (progress: ProgressCallback) => Promise<T>): Promise<T>;
    protected abstract showMenu(opts: qpOpts): Promise<string | undefined>;
    protected abstract showCustomMenu(opts: qpOpts): Promise<qpItem | undefined>;
    protected abstract getCurrentDir(): string | undefined;
    protected abstract getProfileSchemas(): IProfileTypeConfiguration[];
    protected abstract showPrivateKeyWarning(opts: PrivateKeyWarningOptions): Promise<boolean>;
    protected abstract getClientSetting<T>(setting: keyof ISshSession): T | undefined;
    protected abstract showStatusBar(): IDisposable | undefined;
    private migratedConfigs;
    private filteredMigratedConfigs;
    private validationResult;
    private selectedProfile;
    private sshProfiles;
    private sshRegex;
    private flagRegex;
    promptForProfile(profileName?: string, options?: PromptForProfileOptions): Promise<IProfileLoaded | undefined>;
    protected abstract storeServerPath(host: string, path: string): void;
    static validateDeployPath(this: void, input: string): string | null;
    promptForDeployDirectory(host: string, defaultServerPath: string): Promise<string>;
    private createNewProfile;
    private createZoweSchema;
    private validateConfig;
    private attemptConnection;
    private promptForPassword;
    private validateFoundPrivateKeys;
    private setProfile;
    private getNewProfileName;
    private getMergedAttrs;
    private fetchAllSshProfiles;
    private fetchDefaultProfile;
    /**
     * Handle an invalid private key by commenting it out in the configuration file
     * and showing a warning to the user
     */
    private handleInvalidPrivateKey;
}
