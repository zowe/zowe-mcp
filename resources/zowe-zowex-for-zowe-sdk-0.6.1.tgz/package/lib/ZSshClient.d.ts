/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type { SshSession } from "@zowe/zos-uss-for-zowe-sdk";
import type { ClientOptions, CommandRequest, CommandResponse, ExistingClientRequest } from "./doc";
import { RpcClientApi } from "./RpcClientApi";
export declare class ZSshClient extends RpcClientApi implements Disposable {
    static readonly DEFAULT_SERVER_PATH = "~/.zowe-server";
    static readonly BIN_NAME = "zowex";
    private mErrHandler;
    private mResponseTimeout;
    private mServerInfo;
    private mSshClient;
    private mSshStream;
    private mStreamMgr;
    private mPartialStderr;
    private mPartialStdout;
    private readonly mRequestMap;
    private mRequestId;
    private constructor();
    private static defaultErrHandler;
    static create(session: SshSession, opts?: ClientOptions): Promise<ZSshClient>;
    /**
     * Collects all currently pending RPC requests. Can be used to pause, replay, or inspect inflight requests.
     * * @param silence - If true, silences the requests. They will no longer trigger their resolve or reject methods in normal operation (timeout, server response). The caller assumes responsibility for these resolve and rejects.
     * @returns A set of existing client requests currently pending resolution.
     */
    collectAllRequests(silence?: boolean): Set<ExistingClientRequest>;
    /**
     * Cleans up the SSH client by ending the SSH connection and rejecting pending requests
     * that have not been silenced. If you want to silence requests, see {@link collectAllRequests}
     * * @param isRestart - Indicates if the disposal is part of a server restart sequence
     * (changes the rejection message sent to pending requests).
     */
    dispose(isRestart?: boolean): void;
    [Symbol.dispose](): void;
    get serverChecksums(): Record<string, string> | undefined;
    request<T extends CommandResponse>(request: CommandRequest, progressCallback?: (percent: number) => void): Promise<T>;
    private execAsync;
    private getServerStatus;
    private onErrData;
    private onOutData;
    private processResponses;
    private handleNotification;
    private handleResponse;
    /**
     * Type guard to verify if an incoming request parameter contains a function that returns a Node.js Stream.
     * * @param req - The unknown property to inspect.
     * @returns True if `req` is a function, and asserts it as a stream generator function.
     */
    private isStreamFunction;
}
