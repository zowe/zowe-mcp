/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type { Config } from "@zowe/imperative";
export interface CommentedProperty {
    layerPath: string;
    propertyPath: string;
    originalValue: unknown;
    commentText?: string;
}
/**
 * Utility class for commenting out properties in JSON configuration files using Imperative Config API and comment-json
 */
export declare class ConfigFileUtils {
    private static instance;
    private static AFTER_PROPERTIES_SYMBOL;
    private constructor();
    static getInstance(): ConfigFileUtils;
    /**
     * Comment out a property in a team configuration using Config API and comment-json symbol
     * @param teamConfig The team configuration object from Imperative
     * @param profileName The name of the profile
     * @param propertyName The property name to comment out (e.g., "privateKey")
     * @returns Information about the commented property for potential undo operation
     */
    commentOutProperty(teamConfig: Config, profileName: string, propertyName: string): CommentedProperty | undefined;
    /**
     * Removes comments from the given object that match the given text and within the given comment-json symbol.
     * @param obj The object to remove comments from
     * @param text The text to compare against each comment; matches are removed
     * @param commentSymbol The comment-json symbol (`after-all, after:<propertyName>, before-all, before:<propertyName>`) where the comments are located
     */
    private removeCommentsInObject;
    /**
     * Uncomment a previously commented property by restoring it to the configuration
     * @param teamConfig The team configuration object from Imperative
     * @param commentInfo Information about the commented property
     * @returns true if successful, false otherwise
     */
    uncommentProperty(teamConfig: Config, profileName: string, commentInfo: CommentedProperty): boolean;
    /**
     * Delete comment lines related to a commented property
     * @param commentInfo Information about the commented property
     * @returns true if the comment was removed or no longer in file, false otherwise
     */
    deleteCommentedLine(teamConfig: Config, profileName: string, commentInfo: CommentedProperty): boolean;
}
