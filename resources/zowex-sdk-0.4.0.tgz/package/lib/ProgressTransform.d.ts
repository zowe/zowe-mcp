/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { Transform, type TransformCallback } from "node:stream";
import type { CallbackInfo } from "./doc/types";
export declare class ProgressTransform extends Transform {
    private mCallbackInfo?;
    private onDataCallback?;
    private mBytesProcessed;
    private mPercentReported;
    constructor(mCallbackInfo?: CallbackInfo, onDataCallback?: () => void);
    /**
     * Get the total number of bytes written so far
     */
    get bytesProcessed(): number;
    /**
     * Override the transform method to count bytes and invoke progress callback
     */
    _transform(chunk: Buffer | string, encoding: BufferEncoding, callback: TransformCallback): void;
}
