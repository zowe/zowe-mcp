/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { type Stream } from "node:stream";
import type { CallbackInfo, RpcNotification, RpcPromise, RpcRequest } from "./doc";
import type { Client } from "./ssh-rs";
type StreamMode = "GET" | "PUT";
export declare class RpcStreamManager {
    private readonly mSshClient;
    private readonly mPendingStreamMap;
    constructor(mSshClient: Client);
    registerStream(request: RpcRequest, stream: () => Stream, timeoutId?: NodeJS.Timeout, callbackInfo?: CallbackInfo): void;
    linkStreamToPromise(rpcPromise: RpcPromise, notif: RpcNotification, mode: StreamMode): void;
    private uploadStream;
    private downloadStream;
    private expectContentLengthMatches;
}
export {};
