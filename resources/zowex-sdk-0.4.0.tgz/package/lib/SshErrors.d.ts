/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
export interface ISshErrorDefinition {
    summary: string;
    matches: (string | RegExp)[];
    tips?: string[];
    resources?: {
        href: string;
        title: string;
    }[];
}
export declare const SshErrors: Record<string, ISshErrorDefinition>;
/**
 * Common patterns that indicate SSH private key authentication failures
 */
export declare const PrivateKeyFailurePatterns: string[];
