/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { type IProfile } from "@zowe/imperative";
import { SshSession } from "@zowe/zos-uss-for-zowe-sdk";
import type { ConnectConfig } from "ssh2";
export interface ISshCallbacks {
    onProgress?: (increment: number) => void;
    onError?: (error: Error, context: string) => Promise<boolean>;
}
export declare class ZSshUtils {
    private static readonly SERVER_PAX_FILE;
    private static readonly EXPIRED_PASSWORD_CODES;
    /**
     * Routes an expired-password error through `onError` when a callback is registered,
     * or throws an `ImperativeError` directly as a fallback (preserving CLI behavior).
     * Returns `true` if the text contained an expired-password indicator (i.e. the caller
     * should abort the current operation), `false` otherwise.
     */
    private static routeExpiredPasswordError;
    /**
     * Checks if an error message indicates a private key authentication failure
     * @param errorMessage The error message to check
     * @param hasPrivateKey Optional flag to indicate if a private key is configured (for more accurate detection)
     * @returns True if the error indicates a private key authentication failure
     */
    static isPrivateKeyAuthFailure(errorMessage: string, hasPrivateKey?: boolean): boolean;
    static buildSession(args: IProfile): SshSession;
    static buildSshConfig(session: SshSession, configProps?: ConnectConfig): ConnectConfig;
    static installServer(session: SshSession, serverPath: string, options?: ISshCallbacks): Promise<boolean>;
    static uninstallServer(session: SshSession, serverPath: string, options?: Omit<ISshCallbacks, "onProgress">): Promise<void>;
    static checkIfOutdated(remoteChecksums?: Record<string, string>): Promise<boolean>;
    private static getBinDir;
    private static sftp;
}
