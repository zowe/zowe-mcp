/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type { Readable, Writable } from "node:stream";
/**
 * JSON-RPC 2.0 Standard Error Codes
 */
export declare const RpcErrorCode: {
    readonly PARSE_ERROR: -32700;
    readonly INVALID_REQUEST: -32600;
    readonly METHOD_NOT_FOUND: -32601;
    readonly INVALID_PARAMS: -32602;
    readonly INTERNAL_ERROR: -32603;
    readonly REQUEST_TIMEOUT: -32001;
};
export type RpcErrorCodeType = (typeof RpcErrorCode)[keyof typeof RpcErrorCode];
export interface RpcNotification {
    jsonrpc: "2.0";
    method: string;
    params?: any;
}
export interface RpcRequest extends RpcNotification {
    id: number;
}
export interface ErrorDetails {
    code: number;
    message: string;
    data?: any;
}
export interface RpcResponse {
    jsonrpc: "2.0";
    result?: any;
    error?: ErrorDetails;
    id: number;
}
export interface ReadableStreamRpc {
    stream?: () => Readable;
}
export interface WritableStreamRpc {
    stream?: () => Writable;
}
export interface CommandRequest<CommandT extends string = string> {
    /**
     * Requested command to execute
     */
    command: CommandT;
}
export interface CommandResponse {
    /**
     * True if command succeeded
     */
    success: boolean;
}
/**
 * StatusMessage represents the status of the server and serves as a health check
 */
export interface StatusMessage {
    status: string;
    message: string;
    data?: {
        [key: string]: any;
    };
}
export interface IoserverOptions {
    numWorkers?: number;
    verbose?: boolean;
}
export interface ListOptions {
    /**
     * Maximum number of items to return
     */
    maxItems?: number;
    /**
     * Response timeout in seconds
     */
    responseTimeout?: number;
}
export interface ListDatasetOptions {
    /**
     * Skip data sets that come before this data set name
     */
    start?: string;
}
export interface Dataset {
    /**
     * Data set name
     */
    name: string;
    /**
     * Allocated units
     */
    alloc?: number;
    /**
     * Allocated extents
     */
    allocx?: number;
    /**
     * Block size
     */
    blksize?: number;
    /**
     * Creation date
     */
    cdate?: string;
    /**
     * Data class
     */
    dataclass?: string;
    /**
     * Device type
     */
    devtype?: string;
    /**
     * Dsname type (e.g., PDS, LIBRARY)
     */
    dsntype?: string;
    /**
     * Data set organization
     */
    dsorg?: string;
    /**
     * Expiration date
     */
    edate?: string;
    /**
     * Whether the data set is encrypted
     */
    encrypted?: boolean;
    /**
     * Logical record length
     */
    lrecl?: number;
    /**
     * Management class
     */
    mgmtclass?: string;
    /**
     * Whether the data set is migrated
     */
    migrated?: boolean;
    /**
     * Whether the data set is on multiple volumes
     */
    multivolume?: boolean;
    /**
     * Primary units
     */
    primary?: number;
    /**
     * Date last referenced
     */
    rdate?: string;
    /**
     * Record format
     */
    recfm?: string;
    /**
     * Secondary units
     */
    secondary?: number;
    /**
     * Space units
     */
    spacu?: string;
    /**
     * Storage class
     */
    storclass?: string;
    /**
     * Used percentage
     */
    usedp?: number;
    /**
     * Used extents
     */
    usedx?: number;
    /**
     * Volume serial
     */
    volser?: string;
    /**
     * List of volume serials
     */
    volsers?: string[];
}
export interface DatasetAttributes {
    alcunit?: string;
    blksize?: number;
    dirblk?: number;
    dsorg?: string;
    primary: number;
    recfm?: string;
    lrecl: number;
    dataclass?: string;
    unit?: string;
    dsntype?: string;
    mgntclass?: string;
    dsname?: string;
    avgblk?: number;
    secondary?: number;
    size?: string;
    storclass?: string;
    vol?: string;
}
export interface DsMember {
    name: string;
    user?: string;
    vers?: number;
    mod?: number;
    c4date?: string;
    m4date?: string;
    mtime?: string;
    cnorc?: number;
    inorc?: number;
    mnorc?: number;
    sclm?: string;
}
export interface UssItem {
    /**
     * File name
     */
    name: string;
    /**
     * Number of links to the item
     */
    links?: number;
    /**
     * User (owner) of the item
     */
    user?: string;
    /**
     * Group of the item
     */
    group?: string;
    /**
     * Size of the item
     */
    size?: number;
    /**
     * The filetag of the item
     */
    filetag?: string;
    /**
     * Modification date of the item
     */
    mtime?: string;
    /**
     * The permission string of the item
     */
    mode?: string;
}
export interface Job {
    /**
     * Job ID
     */
    id: string;
    /**
     * Job name
     */
    name: string;
    /**
     * JES subsystem (undefined if job was processed by the primary subsystem)
     */
    subsystem?: string;
    /**
     * Job owner
     */
    owner: string;
    /**
     * Job status - INPUT, ACTIVE, OUTPUT
     */
    status: string;
    /**
     * Job type - JOB, STC, TSU
     */
    type: string;
    /**
     * Job execution class
     */
    class: string;
    /**
     * Job return code (undefined if job is not complete)
     */
    retcode?: string;
    /**
     * Job correlator (undefined for JES3 jobs)
     */
    correlator?: string;
    /**
     * Job phase
     */
    phase: number;
    /**
     * Job phase name
     */
    phaseName: string;
}
export interface Spool {
    /**
     * Spool ID
     */
    id: number;
    /**
     * DD name
     */
    ddname: string;
    /**
     * Step name in the job
     */
    stepname: string;
    /**
     * Dataset name
     */
    dsname: string;
    /**
     * Procedure name for the step
     */
    procstep: string;
}
