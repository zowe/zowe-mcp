/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import type * as common from "./common";
export interface IssueTsoCmdRequest extends common.CommandRequest<"tsoCommand"> {
    /**
     * TSO command to execute
     */
    commandText: string;
}
export interface IssueTsoCmdResponse extends common.CommandResponse {
    /**
     * Data returned from the TSO command
     */
    data: string;
}
