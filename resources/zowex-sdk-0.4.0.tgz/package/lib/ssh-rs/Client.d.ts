/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { EventEmitter } from "node:events";
import type { ConnectConfig } from "ssh2";
import { ClientChannel } from "./ClientChannel";
export declare class Client extends EventEmitter {
    private sshClient;
    private disconnectSub;
    private closed;
    private debug;
    connect(config: ConnectConfig): void;
    exec(command: string, callback: (err: Error | undefined, channel: ClientChannel) => void): void;
    end(): void;
    private cleanup;
    private emitClose;
    private connectAsync;
    private authenticate;
    private assertAuthSuccess;
    private execAsync;
}
