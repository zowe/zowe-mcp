/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
import { EventEmitter } from "node:events";
import { PassThrough, Writable } from "node:stream";
import type { Channel } from "russh";
type DebugFn = (message: string) => void;
/**
 * ssh2-compatible ClientChannel backed by a russh-napi Channel.
 *
 * Exposes `.stdin` (Writable), `.stdout` (Readable), `.stderr` (Readable)
 * and a `"close"` event — the subset used by the Zowe SDK.
 */
export declare class ClientChannel extends EventEmitter {
    private readonly inner;
    private readonly debug;
    readonly stdin: Writable;
    readonly stdout: PassThrough;
    readonly stderr: PassThrough;
    private subscriptions;
    private ended;
    private stdoutBytes;
    private stderrBytes;
    private stdinBytes;
    constructor(inner: Channel, debug?: DebugFn);
    /**
     * Drain all incoming data without processing (ssh2 compatibility).
     */
    resume(): this;
    /**
     * Close the channel and clean up subscriptions.
     */
    close(): void;
    private wireObservables;
    private cleanup;
}
export {};
