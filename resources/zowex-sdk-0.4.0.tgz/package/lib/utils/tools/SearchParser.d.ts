/**
 * This program and the accompanying materials are made available under the terms of the
 * Eclipse Public License v2.0 which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-v20.html
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Copyright Contributors to the Zowe Project.
 *
 */
export interface SearchMatch {
    lineNumber: number;
    content: string;
    beforeContext: string[];
    afterContext: string[];
}
export interface SearchMember {
    name: string;
    matches: SearchMatch[];
}
export interface SearchSummary {
    linesFound: number;
    linesProcessed: number;
    membersWithLines: number;
    membersWithoutLines: number;
    compareColumns: string;
    longestLine: number;
    processOptions: string;
    searchPattern: string;
}
export interface SearchResult {
    dataset: string;
    header: string;
    members: SearchMember[];
    summary: SearchSummary;
}
export declare function parseSearchOutput(output: string): SearchResult;
